__version__, __all__ = "0.0.10", ["edprompt"]

from edprompt import *