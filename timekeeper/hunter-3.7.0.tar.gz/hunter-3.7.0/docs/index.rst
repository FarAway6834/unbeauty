========
Contents
========

.. toctree::
   :maxdepth: 2

   readme
   installation
   introduction
   remote
   configuration
   filtering
   cookbook
   reference
   contributing
   authors
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
