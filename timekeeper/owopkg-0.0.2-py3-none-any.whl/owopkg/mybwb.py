cmd = "mybwb"
from . import lib; maingen(globals(), __name__, cmd)