cmd = "build"
from . import lib; maingen(globals(), __name__, cmd)