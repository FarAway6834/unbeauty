cmd = "deploy"
from . import lib; maingen(globals(), __name__, cmd)