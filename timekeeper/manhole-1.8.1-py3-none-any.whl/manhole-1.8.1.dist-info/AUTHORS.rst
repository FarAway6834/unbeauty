
Authors
=======

* Ionel Cristian Mărieș - http://blog.ionelmc.ro
* Saulius Menkevičius - https://github.com/razzmatazz
* Nir Soffer - https://github.com/nirs
* Jesús Cea - https://github.com/jcea
* "honnix" - https://github.com/honnix
* Anton Ryzhov - https://github.com/anton-ryzhov
