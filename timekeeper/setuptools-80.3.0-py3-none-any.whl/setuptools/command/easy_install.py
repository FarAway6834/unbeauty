from setuptools import Command


class easy_install(Command):
    """Stubbed command for temporary pbr compatibility."""
