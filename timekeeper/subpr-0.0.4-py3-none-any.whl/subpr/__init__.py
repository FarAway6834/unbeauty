__version__ = "0.0.4"
__all__ = ["compile", "__main__", "lib"]
