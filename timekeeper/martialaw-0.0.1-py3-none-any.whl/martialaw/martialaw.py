#martialaw.py

from functools import partial

'''
# martialaw.py
function : martialaw(f) to use closer.
PPP Powerfuler Programming by closer Partion, do not impeachment, use closer.

(and I said don't fight with it. It just a joke. plz. I don't care about martial law)
'''

martialaw = partial(partial, partial)
