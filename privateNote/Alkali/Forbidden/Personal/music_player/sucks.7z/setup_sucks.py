#!/usr/bin/python python3

from os import system as s

a, b = '', ''

def main():
    s('chmod u+x ./setup_sucks.py')

    with open('sucks', 'w') as f : f.write(a)

    with open('sucks.py', 'w') as f: f.write(b)

    s('chmod u+x ./sucks')

a = '''\
#!/bin/sh

chmod u+x ./sucks
python sucks.py\
'''

b = '''\
#!/usr/bin/python python3

from platform import system as get_platform
from os import system as s
from time import sleep as sl

quit_signal = False
go = 0

def go_prev():
    global go
    go = -1

def go_next():
    global go
    go = 1

def mp3_play_control_tower(k):
    global go
    if go == -1:
        k.prev()
        k.prev()
    go = 0

if get_platform() == "Windows":
    try: from keyboard import add_hotkey as eventListener
    except:
        s('pip install keyboard')
        from keyboard import add_hotkey as eventListener

    def quit_controller():
        global quit_signal
        quit_signal = True

    def ultimite_quit_controll_toggle():
        pass

    eventListener('q', quit_controller)
    eventListener('p', go_prev)
    # eventListener('d', go_next)

    def mp3player_remote_controller():
        pass

else:
    import sys
    import select
    import tty
    import termios

    def check_ispressed_quit_key(sym = 'q'):
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd) # nessesurry : store state
        try:
            tty.setcbreak(fd)
            return sys.stdin.read(1) == sym if select.select([sys.stdin], [], [], 0.0)[0] else False
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings) # nessesurry : load state

    def ultimite_quit_controll_toggle():
        global quit_signal
        if not quit_signal: quit_signal = check_ispressed_quit_key()
    def mp3player_remote_controller():
        if check_ispressed_quit_key(sym = "p"): go_prev()
        #elif check_ispressed_quit_key(sym = ""): go_next()

def for_playlist_comprehention(f):
    with open(f) as fp:
        for k in fp:
            yield k.strip()

class playlists():

    __slots__ = ("__playlist", "__pointer", "__length")

    def __init__(self, playlist):
        self.__playlist = playlist
        self.__length = len(playlist)
        self.__pointer = -1 % self.__length
    
    def next(self):
        self.__pointer += 1
        self.__pointer %= self.__length
        return self

    def __next__(self):
        return self.next()

    def prev(self):
        self.__pointer -= 1
        self.__pointer %= self.__length
        return self

    def __prev__(self):
        return self.prev()

    def __call__(self):
        return self.__playlist[self.__pointer]

    def __iter__(self):
        return self

playlist = playlists([k for k in for_playlist_comprehention("conf.txt")])

def main():
    mp3player_remote_controller()
    ultimite_quit_controll_toggle() # 시
    if not quit_signal:
        mp3player_remote_controller()
        ultimite_quit_controll_toggle() # 발
        if quit_signal:
            return
        for k in playlist:
            mp3player_remote_controller()
            ultimite_quit_controll_toggle() # 제
            if quit_signal: break
            mp3player_remote_controller()
            ultimite_quit_controll_toggle() # 발
            if quit_signal: break
            mp3_play_control_tower(k)
            ultimite_quit_controll_toggle() # 멈
            if quit_signal: break
            ultimite_quit_controll_toggle() # 추
            if quit_signal: break
            print(f'# ===== [ "{k()}" ] ===== #')
            s(f'mpv "{k()}"')
            mp3player_remote_controller()
            ultimite_quit_controll_toggle() # 라
            if quit_signal: break
            mp3player_remote_controller()
            ultimite_quit_controll_toggle() # 고
            if quit_signal: break
            mp3player_remote_controller()
            for _ in range(25):
                ultimite_quit_controll_toggle() #야!!!!
                sl(0.015)
            for _ in range(25):
                mp3player_remote_controller() #야!!!!
                sl(0.015)
            if quit_signal: break
            ultimite_quit_controll_toggle() # 제
            if quit_signal:break
            mp3player_remote_controller()
            ultimite_quit_controll_toggle() # 발
            if quit_signal: break
            ultimite_quit_controll_toggle() # 좀
            if quit_signal: break
            ultimite_quit_controll_toggle() # 갈!
            if quit_signal: break
            for _ in range(25):
                ultimite_quit_controll_toggle() #야!!!!
                sl(0.015)
            if quit_signal: break
            for _ in range(25):
                mp3player_remote_controller() #야!!!!
                sl(0.015)
            for _ in range(25):
                ultimite_quit_controll_toggle() #야!!!!
                sl(0.015)
            if quit_signal: break
            for _ in range(25):
                mp3player_remote_controller() #야!!!!
                sl(0.015)

    # ultimite_quit_controll_toggle() for stop programm more easier

if __name__ == "__main__": main() #Sucks. danguerus app\
'''

if __name__ == "__main__": main():
